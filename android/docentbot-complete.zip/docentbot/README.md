# DocentBot - 어린이 도서관 도슨트 로봇 앱

DocentBot은 REEMAN AMR(Autonomous Mobile Robot)을 사용하여 어린이 도서관에서 전시관 투어를 제공하는 Android 애플리케이션입니다.

## 주요 기능

### 1. 자동 안내 투어
- 어린이들을 여러 전시 부스로 안내
- 각 부스에서 한국어 음성 설명 제공
- 투어 완료 후 출발지로 자동 복귀

### 2. 인터랙티브 UI
- 깜빡이는 눈과 하품하는 입을 가진 애니메이션 캐릭터
- 큰 원형 시작 버튼
- 직관적인 계속/중지 컨트롤

### 3. 관리자 설정
- AMR IP 주소 구성
- 로봇 연결 상태 모니터링
- 실시간 로봇 위치 추적
- 디버그 콘솔로 모든 이벤트 로깅

### 4. 한국어 TTS (Text-to-Speech)
- 모든 안내 메시지를 한국어 음성으로 출력
- 각 부스별 맞춤형 설명 스크립트

## 기술 스택

- **언어**: Kotlin
- **최소 SDK**: 24 (Android 7.0)
- **타겟 SDK**: 34 (Android 14)
- **주요 라이브러리**:
  - Retrofit 2.9.0 - HTTP API 통신
  - OkHttp 4.11.0 - 네트워크 클라이언트
  - Gson 2.10.1 - JSON 파싱
  - Kotlin Coroutines - 비동기 처리
  - Lottie 6.1.0 - 애니메이션
  - Timber 5.0.1 - 로깅
  - Material Design 3 - UI 컴포넌트

## 프로젝트 구조

```
docentbot/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/library/docentbot/
│   │   │   │   ├── MainActivity.kt           # 메인 액티비티
│   │   │   │   ├── DocentBotApplication.kt   # 앱 초기화
│   │   │   │   ├── api/
│   │   │   │   │   ├── ReemanApiService.kt   # Retrofit API 인터페이스
│   │   │   │   │   └── ReemanRobotManager.kt # 로봇 매니저 클래스
│   │   │   │   └── config/
│   │   │   │       └── BoothConfig.kt        # 부스 설정 로더
│   │   │   ├── assets/
│   │   │   │   └── booth_config.json         # 부스 구성 파일
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   │   ├── activity_main.xml     # 메인 레이아웃
│   │   │   │   │   ├── nav_header.xml        # 네비게이션 헤더
│   │   │   │   │   └── settings_content.xml  # 설정 레이아웃
│   │   │   │   ├── drawable/
│   │   │   │   │   └── ic_menu.xml           # 메뉴 아이콘
│   │   │   │   ├── menu/
│   │   │   │   │   └── drawer_menu.xml       # 드로어 메뉴
│   │   │   │   └── values/
│   │   │   │       ├── strings.xml           # 문자열 리소스
│   │   │   │       ├── colors.xml            # 색상 정의
│   │   │   │       ├── themes.xml            # 앱 테마
│   │   │   │       └── styles.xml            # 스타일 정의
│   │   │   └── AndroidManifest.xml
│   │   └── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
└── README.md
```

## REEMAN AMR API 통합

### HTTP Web API
- **Base URL**: `http://{robot_ip}/`
- **주요 엔드포인트**:
  - `GET /reeman/pose` - 로봇 현재 위치
  - `GET /reeman/nav_status` - 네비게이션 상태
  - `GET /reeman/base_encode` - 배터리 및 센서 상태
  - `POST /cmd/nav_name` - 포인트로 이동
  - `POST /cmd/cancel_goal` - 네비게이션 취소

### 네비게이션 상태
- `0`: Idle (대기)
- `1`: Navigating (이동 중)
- `3`: Arrived (도착)
- `4`: Cancelled (취소됨)

## 부스 구성

`app/src/main/assets/booth_config.json` 파일에서 부스를 구성할 수 있습니다:

```json
{
  "basePoint": "BASE",
  "booths": [
    {
      "id": "A",
      "name": "동화 전시관",
      "navigationPoint": "A",
      "welcomeScript": "환영 메시지...",
      "detailedScript": "상세 설명...",
      "order": 1
    }
  ],
  "messages": {
    "welcome": "안녕 나는 도슨트봇입니다...",
    "tourStart": "투어 시작 메시지...",
    ...
  }
}
```

## 사용 방법

### 1. 로봇 연결
1. 왼쪽 상단 햄버거 메뉴 버튼 클릭
2. AMR IP 주소 입력 (예: 192.168.1.100)
3. "연결" 버튼 클릭
4. 연결 상태가 "연결됨"으로 변경되는지 확인

### 2. 투어 시작
1. 메인 화면에서 "시작" 버튼 클릭
2. 환영 메시지 후 버튼이 "안내시작"으로 변경됨
3. "안내시작" 버튼을 다시 클릭하여 투어 시작

### 3. 투어 진행
- 로봇이 각 부스로 자동 이동
- 부스 도착 시 음성 설명 재생
- "계속" 버튼: 다음 부스로 이동
- "중지" 버튼: 투어 종료 및 출발지 복귀

### 4. 디버그 모니터링
- 설정 메뉴의 디버그 콘솔에서 모든 이벤트 확인
- 로봇 위치 실시간 추적
- 네비게이션 상태 모니터링

## 권한

앱은 다음 권한이 필요합니다:
- `INTERNET` - 로봇 API 통신
- `ACCESS_NETWORK_STATE` - 네트워크 상태 확인
- `ACCESS_WIFI_STATE` - WiFi 연결 상태 확인

## 빌드 방법

```bash
# Android Studio에서 프로젝트 열기
# 또는 커맨드라인에서:
cd /var/www/docent/android/docentbot
./gradlew assembleDebug

# APK 위치:
# app/build/outputs/apk/debug/app-debug.apk
```

## 향후 개선 사항

1. **애니메이션 추가**
   - Lottie 애니메이션 JSON 파일 생성
   - 깜빡이는 눈과 하품하는 입 애니메이션 구현

2. **Serial API 통합**
   - USB Serial 통신 라이브러리 추가
   - 더 직접적인 로봇 제어 구현

3. **오프라인 모드**
   - 네트워크 없이도 기본 기능 동작
   - 캐시된 부스 정보 사용

4. **다국어 지원**
   - 영어, 일본어 등 추가 언어 지원
   - 언어 선택 UI 추가

5. **통계 및 로깅**
   - 투어 완료 횟수 추적
   - 방문객 통계 수집
   - 오류 로그 원격 전송

## 라이센스

이 프로젝트는 어린이 도서관 내부 사용을 위해 개발되었습니다.

## 지원

문제가 발생하거나 질문이 있으신 경우, 개발팀에 문의해주세요.
