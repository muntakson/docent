# DocentBot Deployment Checklist

Use this checklist to ensure proper deployment of the DocentBot application.

## Pre-Deployment

### Development Environment
- [ ] Android Studio installed (Electric Eel 2022.1.1 or later)
- [ ] JDK 11+ installed
- [ ] Android SDK Platform 34 installed
- [ ] Android SDK Build-Tools 33.0.1+ installed
- [ ] Git installed (optional, for version control)

### Project Setup
- [ ] Project imported successfully into Android Studio
- [ ] Gradle sync completed without errors
- [ ] All dependencies resolved
- [ ] No build errors in Android Studio

---

## Configuration

### Robot Setup
- [ ] REEMAN robot is powered on and functional
- [ ] Robot connected to WiFi network
- [ ] Robot IP address noted: `___________________`
- [ ] Robot web interface accessible at `http://[robot-ip]/`
- [ ] Navigation points created on robot:
  - [ ] BASE point saved
  - [ ] A point saved (First booth)
  - [ ] B point saved (Second booth)
  - [ ] C point saved (Third booth)
  - [ ] D point saved (Fourth booth)

### Booth Configuration
- [ ] `booth_config.json` reviewed
- [ ] Booth names match your library's layout
- [ ] Korean welcome scripts are appropriate for children
- [ ] Booth order is correct
- [ ] Navigation point names match robot configuration

### Network Configuration
- [ ] WiFi network name: `___________________`
- [ ] WiFi password: `___________________`
- [ ] Network is stable and has good coverage in library
- [ ] Router allows communication between devices
- [ ] Firewall allows port 80 traffic

---

## Build Process

### Debug Build (Testing)
- [ ] Build → Build APK completed successfully
- [ ] APK file located at `app/build/outputs/apk/debug/app-debug.apk`
- [ ] APK size reasonable (~10-20 MB)
- [ ] Build time recorded: `_______ seconds`

### Release Build (Production)
- [ ] Keystore created and backed up
- [ ] Keystore location: `___________________`
- [ ] Keystore password stored securely
- [ ] Key alias: `___________________`
- [ ] Key password stored securely
- [ ] Signed APK generated successfully
- [ ] APK located at `app/build/outputs/apk/release/app-release.apk`

---

## Installation

### Device Preparation
- [ ] Android device meets minimum requirements (Android 7.0+)
- [ ] Device model: `___________________`
- [ ] Android version: `___________________`
- [ ] Developer options enabled on device
- [ ] USB debugging enabled
- [ ] Install from unknown sources allowed (if installing from APK)

### App Installation
- [ ] APK transferred to device (or installed via Android Studio)
- [ ] App installed successfully
- [ ] App icon appears in app drawer
- [ ] App launches without crashing
- [ ] No permission errors on first launch

---

## Initial Testing

### Connection Tests
- [ ] Device connected to same WiFi as robot
- [ ] App settings opened successfully
- [ ] Robot IP address entered correctly
- [ ] "연결" (Connect) button tapped
- [ ] Connection status shows "연결됨" (Connected)
- [ ] Robot position updates in settings
- [ ] Position shows reasonable X, Y, θ values
- [ ] Debug console shows log messages

### TTS (Text-to-Speech) Tests
- [ ] Korean language pack installed on device
- [ ] TTS test in Android settings successful
- [ ] "시작" button plays welcome message in Korean
- [ ] Audio is clear and at appropriate volume
- [ ] No robotic or garbled speech

### Navigation Tests
- [ ] First click on "시작" button works
- [ ] Welcome message plays: "안녕 나는 도슨트봇입니다..."
- [ ] Button changes to "안내시작"
- [ ] Second click starts navigation
- [ ] Robot moves toward first booth (A)
- [ ] Status text updates during navigation
- [ ] Arrival detection works (robot reaches booth)
- [ ] Korean explanation plays at booth
- [ ] Continue and Stop buttons appear

### Tour Flow Tests
- [ ] Full tour completes all booths in order (A → B → C → D)
- [ ] At each booth:
  - [ ] Robot arrives correctly
  - [ ] Korean explanation plays
  - [ ] Continue/Stop buttons work
- [ ] "계속" button advances to next booth
- [ ] "중지" button cancels and returns to base
- [ ] After last booth, robot returns to base automatically
- [ ] UI resets correctly after tour completion
- [ ] App ready for next tour

---

## Advanced Testing

### Error Handling
- [ ] Test with robot turned off - shows connection error
- [ ] Test with wrong IP address - shows connection failed
- [ ] Test obstacle blocking robot - navigation error handled
- [ ] Test cancelling mid-navigation - returns to base
- [ ] Test low robot battery - warning displayed (if configured)

### Performance Tests
- [ ] Navigation status updates within 1-2 seconds
- [ ] Battery level updates within 10-15 seconds
- [ ] No lag when tapping buttons
- [ ] No excessive battery drain on phone
- [ ] App doesn't crash after extended use (30+ minutes)
- [ ] Multiple tours in succession work correctly

### UI/UX Tests
- [ ] All Korean text displays correctly (no �� characters)
- [ ] Buttons are tappable and responsive
- [ ] Status messages are clear and helpful
- [ ] Debug console scrolls properly
- [ ] Drawer menu opens and closes smoothly
- [ ] Settings persist across app restarts (if implemented)

---

## User Acceptance Testing

### Librarian Testing
- [ ] Librarian can start app independently
- [ ] Connection process is clear
- [ ] Starting a tour is intuitive
- [ ] Stopping a tour works as expected
- [ ] Librarian comfortable with troubleshooting

### Child User Testing
- [ ] Children can see and tap the start button easily
- [ ] Audio volume is appropriate for library environment
- [ ] Korean speech is clear and understandable for children
- [ ] Tour pacing is appropriate (not too fast/slow)
- [ ] Children remain engaged throughout tour

### Environmental Testing
- [ ] Test in actual library environment
- [ ] WiFi signal strong throughout tour path
- [ ] Robot navigates around library furniture successfully
- [ ] Audio audible over ambient library noise
- [ ] No interference from other WiFi devices

---

## Documentation

### User Documentation
- [ ] Quick start guide provided to librarians
- [ ] Troubleshooting guide available
- [ ] Contact information for support provided
- [ ] Booth content explanation documented

### Technical Documentation
- [ ] BUILD_INSTRUCTIONS.md reviewed
- [ ] README.md up to date
- [ ] DEVELOPMENT_NOTES.md complete
- [ ] Code comments added where necessary
- [ ] Git repository set up (if using version control)

### Training
- [ ] Librarian training session completed
- [ ] Training materials created
- [ ] FAQ document created
- [ ] Emergency procedures documented

---

## Production Deployment

### Final Preparations
- [ ] All tests passed
- [ ] Known issues documented
- [ ] Backup of configuration files created
- [ ] Backup of APK created
- [ ] Rollback plan prepared

### Installation
- [ ] Production APK installed on library device
- [ ] Robot configured with correct navigation points
- [ ] WiFi credentials entered and tested
- [ ] Robot IP address configured correctly
- [ ] Initial connection test successful

### Handover
- [ ] App demonstrated to library staff
- [ ] All documentation provided
- [ ] Support contact information shared
- [ ] Maintenance schedule discussed
- [ ] Feedback mechanism established

---

## Post-Deployment

### Monitoring (First Week)
- [ ] Daily check-ins with library staff
- [ ] Review debug logs for errors
- [ ] Monitor tour success rate
- [ ] Collect user feedback
- [ ] Address any issues immediately

### Monitoring (First Month)
- [ ] Weekly check-ins
- [ ] Review accumulated logs
- [ ] Analyze usage patterns
- [ ] Gather child feedback
- [ ] Plan improvements

### Maintenance Schedule
- [ ] Weekly: Check robot navigation points
- [ ] Monthly: Update booth content if needed
- [ ] Quarterly: Review app performance
- [ ] Annually: Update Android dependencies

---

## Sign-Off

### Deployment Team
- [ ] Developer sign-off: `___________________` Date: `__________`
- [ ] Project Manager sign-off: `___________________` Date: `__________`
- [ ] QA sign-off: `___________________` Date: `__________`

### Library Acceptance
- [ ] Library Manager sign-off: `___________________` Date: `__________`
- [ ] IT Manager sign-off: `___________________` Date: `__________`

### Notes
```
_________________________________________________________________
_________________________________________________________________
_________________________________________________________________
_________________________________________________________________
_________________________________________________________________
```

---

## Emergency Contacts

| Role | Name | Contact |
|------|------|---------|
| Developer | _____________ | _____________ |
| Library IT | _____________ | _____________ |
| REEMAN Support | _____________ | _____________ |
| Project Manager | _____________ | _____________ |

---

## Rollback Procedure

If critical issues occur after deployment:

1. **Stop using the app immediately**
2. **Document the issue**:
   - What happened?
   - When did it happen?
   - Error messages?
   - Debug console logs?

3. **Contact development team**

4. **Temporary solution**:
   - Use manual robot control if needed
   - Postpone tours until fix is deployed

5. **Rollback steps** (if necessary):
   - Uninstall current version
   - Install previous working version (keep backup!)
   - Reconfigure settings
   - Test before resuming tours

---

**Deployment Date**: `__________`
**Version**: `1.0`
**Deployed By**: `__________`
**Status**: `__________`
