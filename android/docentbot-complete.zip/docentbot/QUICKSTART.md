# DocentBot - Quick Start Guide

## 🚀 5-Minute Setup (If You Have Android Studio)

### 1. Import Project
```
File → Open → Select 'docentbot' folder → OK
```

### 2. Sync Gradle
```
Click "Sync Now" when prompted
Wait for dependencies to download
```

### 3. Build APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
Click "locate" when done
```

### 4. Install on Phone
```
Connect phone via USB
Click Run button (▶️)
Select your device
```

### 5. Configure Robot
```
Open app → Tap ☰ menu
Enter robot IP: 192.168.1.XXX
Tap "연결" (Connect)
```

### 6. Set Up Robot Points
On the REEMAN robot, save these positions:
- `BASE` - Home position
- `A` - First booth
- `B` - Second booth
- `C` - Third booth
- `D` - Fourth booth

### 7. Test!
```
Tap "시작" button
Should hear: "안녕 나는 도슨트봇입니다..."
Tap "안내시작"
Robot should navigate to booth A
```

---

## 📱 Without Android Studio?

### Download Android Studio
https://developer.android.com/studio

Includes everything you need:
- IDE
- Android SDK
- Build tools
- Emulator

Installation time: ~15 minutes
First build time: ~10 minutes

---

## ⚠️ Common First-Time Issues

| Problem | Solution |
|---------|----------|
| Build fails | Click File → Invalidate Caches / Restart |
| Can't connect to robot | Check WiFi - phone and robot must be on same network |
| TTS doesn't speak Korean | Install Korean language pack in Android settings |
| Navigation fails | Verify robot has points named exactly: BASE, A, B, C, D |

---

## 📖 Full Documentation

- **BUILD_INSTRUCTIONS.md** - Complete step-by-step build guide
- **README.md** - Project overview and features
- **DEVELOPMENT_NOTES.md** - Technical implementation details

---

## 🎯 Project Structure

```
docentbot/
├── app/
│   ├── src/main/
│   │   ├── java/com/library/docentbot/
│   │   │   ├── MainActivity.kt              ← Main UI logic
│   │   │   ├── api/
│   │   │   │   ├── ReemanApiService.kt      ← HTTP API
│   │   │   │   └── ReemanRobotManager.kt    ← Robot control
│   │   │   └── config/
│   │   │       └── BoothConfig.kt           ← Config loader
│   │   ├── assets/
│   │   │   └── booth_config.json            ← Edit booth info here!
│   │   └── res/
│   │       └── layout/                      ← UI layouts
│   └── build.gradle                         ← App configuration
├── build.gradle                             ← Project configuration
└── settings.gradle                          ← Gradle settings
```

---

## 💡 Tips

1. **First Run**: Korean TTS might prompt to download language data. Allow it.

2. **Customization**: Edit `app/src/main/assets/booth_config.json` to change:
   - Booth names
   - Korean scripts
   - Welcome messages

3. **Debugging**: Use Settings → Debug Console to see all events in real-time

4. **WiFi**: Use 5GHz WiFi for better performance if available

---

## ✅ Ready to Go!

For detailed instructions, see **BUILD_INSTRUCTIONS.md**

For technical details, see **DEVELOPMENT_NOTES.md**

**Happy coding! 🤖📚**
