# DocentBot - Build and Installation Instructions

## Prerequisites

### Required Software
1. **Android Studio** (Electric Eel 2022.1.1 or later)
   - Download from: https://developer.android.com/studio

2. **Java Development Kit (JDK) 11 or later**
   - Android Studio includes JDK, or download from: https://adoptium.net/

3. **Android SDK Components** (installed via Android Studio):
   - Android SDK Platform 34
   - Android SDK Build-Tools 33.0.1 or later
   - Android SDK Platform-Tools
   - Android Emulator (optional, for testing without physical device)

### Device Requirements
- Android device running Android 7.0 (API 24) or later
- Developer options enabled
- USB debugging enabled (for installation via computer)

---

## Step 1: Import Project into Android Studio

### Option A: Transfer from Server
1. On the server, create a zip archive:
   ```bash
   cd /var/www/docent/android
   zip -r docentbot.zip docentbot/
   ```

2. Transfer `docentbot.zip` to your development machine

3. Extract the zip file on your development machine

### Option B: Clone/Copy Directly
If you have direct access to the server files:
1. Copy the entire `/var/www/docent/android/docentbot` directory to your development machine

### Import into Android Studio
1. Open Android Studio
2. Click **File → Open**
3. Navigate to the `docentbot` folder
4. Click **OK**
5. Android Studio will automatically detect it as an Android project and import it

---

## Step 2: Sync and Build

### Initial Sync
1. Android Studio will prompt to sync Gradle files - click **Sync Now**
2. Wait for Gradle sync to complete (first time may take 5-10 minutes)
3. Android Studio will download all required dependencies

### Resolve Any SDK Issues
If you see errors about missing SDK components:
1. Click on the error message
2. Click **Install missing SDK package(s)**
3. Accept licenses and wait for installation

---

## Step 3: Build the APK

### Debug Build (for testing)
1. In Android Studio, click **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for build to complete (usually 30-60 seconds)
3. When complete, you'll see a notification: "APK(s) generated successfully"
4. Click **locate** to find the APK file
5. The APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

### Release Build (for production)
1. First, generate a signing key (one-time setup):
   - Click **Build → Generate Signed Bundle / APK**
   - Select **APK** and click **Next**
   - Click **Create new...** to create a new keystore
   - Fill in the details and remember the passwords!
   - Click **OK**

2. Build signed APK:
   - Click **Build → Generate Signed Bundle / APK**
   - Select **APK** and click **Next**
   - Select your keystore and enter passwords
   - Choose **release** build variant
   - Click **Finish**
   - APK will be at: `app/build/outputs/apk/release/app-release.apk`

---

## Step 4: Install on Android Device

### Method 1: Direct Install from Android Studio
1. Connect your Android phone to computer via USB
2. Enable **USB Debugging** on phone:
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times to enable Developer Options
   - Go back to Settings → Developer Options
   - Enable "USB Debugging"
3. In Android Studio, click the **Run** button (green play icon)
4. Select your device from the list
5. App will be installed and launched automatically

### Method 2: Install via ADB (Command Line)
1. Connect phone via USB
2. Open terminal/command prompt
3. Navigate to the APK location:
   ```bash
   cd app/build/outputs/apk/debug
   ```
4. Install using ADB:
   ```bash
   adb install app-debug.apk
   ```

   If you get "device unauthorized":
   - Check your phone for an authorization prompt
   - Tap "Allow" and try again

### Method 3: Transfer APK to Phone
1. Copy the APK file to your phone:
   - Email it to yourself
   - Use Google Drive, Dropbox, etc.
   - Transfer via USB cable to phone's Downloads folder

2. On your phone:
   - Open the file manager
   - Navigate to the APK file
   - Tap on it to install
   - If you see "Install from Unknown Sources" warning:
     - Go to Settings → Security
     - Enable "Unknown Sources" or "Install from Unknown Apps"
     - Go back and tap APK again

---

## Step 5: Configure the App

### First Launch Setup
1. Launch the DocentBot app
2. Tap the hamburger menu (☰) in top left corner
3. Configure the following:

#### A. Robot IP Address
- Enter your REEMAN robot's IP address
- Format: `192.168.1.XXX` (replace XXX with actual value)
- To find robot IP:
  - Connect to robot's web interface
  - Or check your WiFi router's connected devices

#### B. Network Setup
- Ensure phone and robot are on the same WiFi network
- Both should have stable connections

#### C. Test Connection
- Tap the **연결 (Connect)** button
- Status should change to **연결됨 (Connected)**
- Robot position should start updating

---

## Step 6: Configure Robot Navigation Points

Before using the tour functionality, you **MUST** set up navigation points on the REEMAN robot:

### Required Navigation Points
The app expects these exact point names:
- **BASE** - Starting/home position
- **A** - First booth (동화 전시관 - Fairy Tales)
- **B** - Second booth (과학 전시관 - Science)
- **C** - Third booth (역사 전시관 - History)
- **D** - Fourth booth (만화 전시관 - Comics)

### How to Set Navigation Points

#### Method 1: Using REEMAN Web Interface
1. Connect to robot's web interface: `http://[robot-ip]/`
2. Navigate to the mapping/positioning section
3. Drive robot to the first position
4. Save position with name "BASE"
5. Repeat for positions A, B, C, D

#### Method 2: Using REEMAN Mobile App
1. Open REEMAN control app
2. Navigate to map/positioning mode
3. Drive robot to each position
4. Save each point with the exact names above

### Verify Navigation Points
1. In DocentBot app, go to Settings
2. Check the debug console
3. Robot position should be visible
4. Test navigation by starting a tour

---

## Customizing Booth Information

### Edit Booth Scripts
The booth names, positions, and Korean explanations are configured in:
`app/src/main/assets/booth_config.json`

To customize:
1. Open `booth_config.json` in Android Studio
2. Edit the booth information:
   ```json
   {
     "id": "A",
     "name": "동화 전시관",
     "navigationPoint": "A",
     "welcomeScript": "Your Korean welcome message here...",
     "detailedScript": "Detailed explanation...",
     "order": 1
   }
   ```
3. Save the file
4. Rebuild the APK
5. Reinstall on device

### Adding More Booths
1. Add new booth entries to the `booths` array
2. Ensure `navigationPoint` matches point names on robot
3. Set unique `order` values
4. Rebuild and reinstall

---

## Troubleshooting

### Build Errors

**"SDK location not found"**
- Solution: Android Studio should create `local.properties` automatically
- If not, create it manually with: `sdk.dir=/path/to/your/Android/Sdk`

**"Gradle sync failed"**
- Solution: Click **File → Invalidate Caches / Restart**
- Try **Build → Clean Project**, then **Build → Rebuild Project**

**Dependency resolution errors**
- Solution: Check internet connection
- Try changing Maven repository in build.gradle

### Installation Errors

**"App not installed"**
- Solution: Uninstall any existing version first
- Check if device has enough storage space

**"Install blocked"**
- Solution: Enable "Install from Unknown Sources" in device settings

### Runtime Errors

**Korean TTS not working**
- Solution: Install Korean language pack on Android device
- Go to Settings → Language & Input → Text-to-Speech
- Download Korean language data

**Cannot connect to robot**
- Check robot IP address is correct
- Verify phone and robot are on same WiFi network
- Check robot's web service is running (test in browser: `http://[robot-ip]/`)
- Check firewall settings

**Navigation not working**
- Verify navigation points are set up on robot with exact names
- Check robot position updates in debug console
- Ensure robot is in navigation mode (not mapping mode)

---

## Testing Checklist

Before deploying to production, test the following:

- [ ] App installs successfully
- [ ] Korean TTS speaks correctly
- [ ] Can connect to robot (status shows "연결됨")
- [ ] Robot position updates in settings
- [ ] First click on "시작" button plays welcome message
- [ ] Button changes to "안내시작"
- [ ] Second click starts tour
- [ ] Robot navigates to first booth
- [ ] Arrival triggers Korean explanation
- [ ] Continue/Stop buttons appear
- [ ] "계속" button moves to next booth
- [ ] "중지" button returns to base
- [ ] All 4 booths are visited in sequence
- [ ] After last booth, automatically returns to base
- [ ] UI resets after tour completion
- [ ] Debug console logs all events
- [ ] Battery level updates

---

## Performance Tips

1. **WiFi Signal Strength**
   - Keep phone and robot within good WiFi range
   - Use 5GHz WiFi if available for better performance

2. **Battery Management**
   - Robot should be >30% battery for tours
   - Monitor battery level in settings panel

3. **App Performance**
   - Close other apps before starting tours
   - Restart app if it becomes slow

4. **Network Latency**
   - Normal latency: navigation status updates within 1-2 seconds
   - If slower, check WiFi connection quality

---

## Support and Maintenance

### Logs and Debugging
- All events are logged in the debug console
- Access via hamburger menu → Settings → Debug Console
- Tap "콘솔 지우기" to clear old logs

### Updating the App
1. Make changes to code in Android Studio
2. Increment `versionCode` and `versionName` in `app/build.gradle`
3. Build new APK
4. Uninstall old version from phone
5. Install new APK

### Backup Important Files
Always keep backups of:
- `booth_config.json` - Booth configurations
- Signing keystore (for release builds)
- This documentation

---

## Quick Reference

### Key Files
- **MainActivity.kt** - Main app logic
- **ReemanRobotManager.kt** - Robot control
- **booth_config.json** - Booth data
- **build.gradle** - App configuration

### Default Settings
- Min Android version: 7.0 (API 24)
- Target Android version: 14 (API 34)
- Default robot IP: 192.168.1.100
- Navigation check interval: 1 second
- Battery check interval: 10 seconds

### Contact for Issues
- Check README.md for project overview
- Review DEVELOPMENT_NOTES.md for technical details
- Check GitHub issues (if repository is set up)

---

**Ready to build? Follow the steps above and you'll have DocentBot running on your phone in about 30 minutes!**
