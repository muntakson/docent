package com.library.docentbot.api

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

// Data classes for API responses
data class PoseResponse(
    val x: Double,
    val y: Double,
    val theta: Double
)

data class NavStatusResponse(
    val res: Int,
    val code: Int,
    val goal: String,
    val dist: Double,
    val mileage: Double
)

data class BaseEncodeResponse(
    val battery: Int,
    val chargeFlag: Int,
    val emergencyButton: Int
)

data class NavResult(
    val state: Int,      // 0:initial, 1:starting, 2:pause, 3:complete, 4:cancelled, 5:recovery, 6:command received
    val code: Int,       // Error codes
    val name: String,    // Target point name
    val dist_to_goal: Double,
    val mileage: Double
)

// Retrofit API Interface
interface ReemanApiService {

    @GET("reeman/pose")
    suspend fun getPose(): Response<PoseResponse>

    @GET("reeman/nav_status")
    suspend fun getNavStatus(): Response<String>  // Returns raw string to parse

    @GET("reeman/base_encode")
    suspend fun getBaseEncode(): Response<BaseEncodeResponse>

    @POST("cmd/nav_name")
    @Headers("Content-Type: application/json")
    suspend fun navigateToPoint(@Body request: Map<String, String>): Response<String>

    @POST("cmd/cancel_goal")
    suspend fun cancelNavigation(): Response<String>

    @GET("reeman/position")
    suspend fun getAllPositions(): Response<String>

    @GET("reeman/hostname")
    suspend fun getHostname(): Response<Map<String, String>>

    companion object {
        fun create(baseUrl: String): ReemanApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit.create(ReemanApiService::class.java)
        }
    }
}
