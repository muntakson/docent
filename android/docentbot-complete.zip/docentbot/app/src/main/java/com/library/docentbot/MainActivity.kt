package com.library.docentbot

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.library.docentbot.api.ReemanRobotManager
import com.library.docentbot.config.Booth
import com.library.docentbot.config.BoothConfigLoader
import com.library.docentbot.databinding.ActivityMainBinding
import com.library.docentbot.databinding.SettingsContentBinding
import com.google.android.material.navigation.NavigationView
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import timber.log.Timber
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsBinding: SettingsContentBinding

    private var robotManager: ReemanRobotManager? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var currentBoothIndex = 0
    private var booths: List<Booth> = emptyList()

    private var navigationMonitorJob: Job? = null
    private var batteryMonitorJob: Job? = null

    enum class UIState {
        IDLE, READY_TO_START, NAVIGATING, AT_BOOTH, RETURNING
    }

    private var currentState = UIState.IDLE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initializeComponents()
        setupUI()
        setupDrawer()
    }

    private fun initializeComponents() {
        // Load booth configuration
        booths = BoothConfigLoader.getBooths(this)
        addDebugLog("부스 설정 로드됨: ${booths.size}개")

        // Initialize TTS
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale.KOREAN)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Timber.e("Korean language not supported")
                    addDebugLog("경고: 한국어 TTS 지원 안됨")
                } else {
                    isTtsReady = true
                    Timber.d("TTS initialized successfully")
                    addDebugLog("TTS 초기화 성공")
                }
            } else {
                Timber.e("TTS initialization failed")
                addDebugLog("TTS 초기화 실패")
            }
        }
    }

    private fun setupUI() {
        // Start button click
        binding.startButton.setOnClickListener {
            when (currentState) {
                UIState.IDLE -> {
                    // First click - greet and change to "안내시작"
                    val messages = BoothConfigLoader.getMessages(this)
                    speak(messages?.welcome ?: getString(R.string.welcome_message))
                    binding.startButton.text = getString(R.string.start_tour)
                    currentState = UIState.READY_TO_START
                    addDebugLog("환영 메시지 재생")
                }
                UIState.READY_TO_START -> {
                    // Second click - start tour
                    startTour()
                }
                else -> {}
            }
        }

        // Continue button
        binding.btnContinue.setOnClickListener {
            continueToNextBooth()
        }

        // Stop button
        binding.btnStop.setOnClickListener {
            stopTour()
        }

        // Menu button
        binding.btnMenu.setOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }
    }

    private fun setupDrawer() {
        val navigationView = findViewById<NavigationView>(R.id.navigationView)
        val headerView = navigationView.getHeaderView(0)

        // Inflate settings content into navigation view
        val settingsContainer = navigationView.findViewById<View>(R.id.nav_settings)
        settingsBinding = SettingsContentBinding.inflate(layoutInflater, navigationView, false)

        // Remove menu and use custom layout
        navigationView.removeHeaderView(headerView)
        navigationView.menu.clear()
        navigationView.addView(settingsBinding.root)

        setupSettingsListeners()

        // Display app IP
        settingsBinding.tvAppIp.text = getLocalIpAddress()
    }

    private fun setupSettingsListeners() {
        // Connect button
        settingsBinding.btnConnect.setOnClickListener {
            val amrIp = settingsBinding.etAmrIp.text.toString()
            connectToRobot(amrIp)
        }

        // Clear console button
        settingsBinding.btnClearConsole.setOnClickListener {
            settingsBinding.tvDebugConsole.text = "Debug console cleared...\n"
        }
    }

    private fun connectToRobot(ipAddress: String) {
        addDebugLog("연결 시도: $ipAddress")
        settingsBinding.tvConnectionStatus.text = "연결 중..."
        settingsBinding.tvConnectionStatus.setTextColor(getColor(android.R.color.holo_orange_dark))

        robotManager = ReemanRobotManager(ipAddress)

        lifecycleScope.launch {
            val connected = robotManager?.checkConnection() ?: false

            if (connected) {
                settingsBinding.tvConnectionStatus.text = "연결됨"
                settingsBinding.tvConnectionStatus.setTextColor(getColor(android.R.color.holo_green_dark))
                addDebugLog("로봇 연결 성공")

                // Start monitoring
                startMonitoring()
            } else {
                settingsBinding.tvConnectionStatus.text = "연결 실패"
                settingsBinding.tvConnectionStatus.setTextColor(getColor(android.R.color.holo_red_dark))
                addDebugLog("로봇 연결 실패")
            }
        }
    }

    private fun startMonitoring() {
        // Monitor navigation status
        navigationMonitorJob = lifecycleScope.launch {
            while (isActive) {
                robotManager?.monitorNavigationStatus()?.let { navStatus ->
                    robotManager?.updateNavigationState(navStatus)

                    withContext(Dispatchers.Main) {
                        updateRobotPosition()
                        addDebugLog("상태: res=${navStatus.res}, code=${navStatus.code}, goal=${navStatus.goal}")
                    }
                }
                delay(1000) // Check every second
            }
        }

        // Monitor battery
        batteryMonitorJob = lifecycleScope.launch {
            while (isActive) {
                robotManager?.updateBatteryStatus()
                delay(10000) // Check every 10 seconds
            }
        }

        // Observe navigation state changes
        lifecycleScope.launch {
            robotManager?.navigationStatus?.collectLatest { state ->
                handleNavigationStateChange(state)
            }
        }
    }

    private suspend fun updateRobotPosition() {
        val pose = robotManager?.getCurrentPose()
        pose?.let {
            settingsBinding.tvRobotPosition.text =
                "X: %.2f, Y: %.2f, θ: %.2f°".format(it.x, it.y, Math.toDegrees(it.theta))
        }
    }

    private fun handleNavigationStateChange(state: ReemanRobotManager.NavigationState) {
        when (state) {
            is ReemanRobotManager.NavigationState.Idle -> {
                binding.tvStatus.text = "대기 중"
                addDebugLog("네비게이션: 대기")
            }
            is ReemanRobotManager.NavigationState.Navigating -> {
                binding.tvStatus.text = "이동 중..."
                addDebugLog("네비게이션: 이동 중")
            }
            is ReemanRobotManager.NavigationState.Arrived -> {
                onBoothArrived(state.pointName)
            }
            is ReemanRobotManager.NavigationState.Error -> {
                binding.tvStatus.text = "오류: ${state.message}"
                addDebugLog("네비게이션 오류: ${state.message}")
            }
            is ReemanRobotManager.NavigationState.Cancelled -> {
                binding.tvStatus.text = "취소됨"
                addDebugLog("네비게이션: 취소됨")
            }
        }
    }

    private fun startTour() {
        if (robotManager == null) {
            val messages = BoothConfigLoader.getMessages(this)
            speak(messages?.connectionRequired ?: "먼저 로봇에 연결해주세요")
            addDebugLog("오류: 로봇 미연결")
            return
        }

        currentBoothIndex = 0
        currentState = UIState.NAVIGATING

        binding.startButton.visibility = View.GONE

        val messages = BoothConfigLoader.getMessages(this)
        speak(messages?.tourStart ?: "투어를 시작하겠습니다")
        binding.tvStatus.text = "투어 시작!"

        addDebugLog("투어 시작")
        navigateToCurrentBooth()
    }

    private fun navigateToCurrentBooth() {
        if (currentBoothIndex >= booths.size) {
            returnToBase()
            return
        }

        val booth = booths[currentBoothIndex]
        val messages = BoothConfigLoader.getMessages(this)
        val navigatingMessage = messages?.navigatingTo?.replace("{name}", booth.name)
            ?: "${booth.name}으로 이동합니다"

        speak(navigatingMessage)
        binding.tvStatus.text = "${booth.name}으로 이동 중..."
        addDebugLog("${booth.id} 부스로 네비게이션 시작")

        lifecycleScope.launch {
            robotManager?.navigateToPoint(booth.navigationPoint)
        }
    }

    private fun onBoothArrived(pointName: String) {
        currentState = UIState.AT_BOOTH
        addDebugLog("도착: $pointName")

        // Find booth by navigation point
        val booth = booths.find { it.navigationPoint == pointName }
        if (booth != null) {
            speak(booth.welcomeScript)
            binding.tvStatus.text = "${booth.name} 도착"
        } else {
            speak("${pointName} 전시장에 도착했습니다")
            binding.tvStatus.text = "${pointName} 도착"
        }

        // Show continue/stop buttons
        binding.controlButtonsContainer.visibility = View.VISIBLE
    }

    private fun continueToNextBooth() {
        binding.controlButtonsContainer.visibility = View.GONE
        currentBoothIndex++
        currentState = UIState.NAVIGATING
        navigateToCurrentBooth()
    }

    private fun stopTour() {
        val messages = BoothConfigLoader.getMessages(this)
        speak(messages?.tourCancelled ?: "투어를 종료하고 돌아갑니다")
        addDebugLog("투어 중지 요청")

        binding.controlButtonsContainer.visibility = View.GONE
        currentState = UIState.RETURNING

        lifecycleScope.launch {
            robotManager?.cancelNavigation()
            delay(500)
            returnToBase()
        }
    }

    private fun returnToBase() {
        val messages = BoothConfigLoader.getMessages(this)
        val isComplete = currentBoothIndex >= booths.size

        val returnMessage = if (isComplete) {
            messages?.tourComplete ?: "투어를 마쳤습니다. 출발지로 돌아갑니다"
        } else {
            messages?.returningToBase ?: "출발지로 돌아갑니다"
        }

        speak(returnMessage)
        binding.tvStatus.text = "출발지로 복귀 중..."
        addDebugLog("베이스로 복귀")

        lifecycleScope.launch {
            val basePoint = BoothConfigLoader.getBasePoint(this@MainActivity)
            robotManager?.navigateToPoint(basePoint)
            delay(3000) // Wait for navigation to complete

            // Reset UI
            withContext(Dispatchers.Main) {
                currentState = UIState.IDLE
                currentBoothIndex = 0
                binding.startButton.text = getString(R.string.start)
                binding.startButton.visibility = View.VISIBLE
                binding.controlButtonsContainer.visibility = View.GONE
                binding.tvStatus.text = ""
                addDebugLog("투어 완료")
            }
        }
    }

    private fun speak(text: String) {
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
            addDebugLog("TTS: $text")
        } else {
            Timber.w("TTS not ready, cannot speak: $text")
            addDebugLog("TTS 준비 안됨: $text")
        }
    }

    private fun addDebugLog(message: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val logMessage = "[$timestamp] $message\n"

        runOnUiThread {
            if (::settingsBinding.isInitialized) {
                settingsBinding.tvDebugConsole.append(logMessage)
            }
        }
        Timber.d(message)
    }

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address.address.size == 4) {
                        return address.hostAddress ?: "Unknown"
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to get IP address")
        }
        return "0.0.0.0"
    }

    override fun onDestroy() {
        super.onDestroy()
        navigationMonitorJob?.cancel()
        batteryMonitorJob?.cancel()
        tts?.stop()
        tts?.shutdown()
    }
}
