package com.library.docentbot.api

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import timber.log.Timber

class ReemanRobotManager(private val robotIp: String) {

    private val baseUrl = "http://$robotIp/"
    private val apiService = ReemanApiService.create(baseUrl)

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus

    private val _navigationStatus = MutableStateFlow<NavigationState>(NavigationState.Idle)
    val navigationStatus: StateFlow<NavigationState> = _navigationStatus

    private val _robotPose = MutableStateFlow<PoseResponse?>(null)
    val robotPose: StateFlow<PoseResponse?> = _robotPose

    private val _batteryLevel = MutableStateFlow(100)
    val batteryLevel: StateFlow<Int> = _batteryLevel

    enum class ConnectionStatus {
        CONNECTED, DISCONNECTED, CONNECTING, ERROR
    }

    sealed class NavigationState {
        object Idle : NavigationState()
        object Navigating : NavigationState()
        data class Arrived(val pointName: String) : NavigationState()
        data class Error(val message: String) : NavigationState()
        object Cancelled : NavigationState()
    }

    suspend fun checkConnection(): Boolean {
        return try {
            _connectionStatus.value = ConnectionStatus.CONNECTING
            val response = apiService.getHostname()
            if (response.isSuccessful) {
                _connectionStatus.value = ConnectionStatus.CONNECTED
                Timber.d("Connected to robot: ${response.body()}")
                true
            } else {
                _connectionStatus.value = ConnectionStatus.ERROR
                false
            }
        } catch (e: Exception) {
            Timber.e(e, "Connection failed")
            _connectionStatus.value = ConnectionStatus.DISCONNECTED
            false
        }
    }

    suspend fun getCurrentPose(): PoseResponse? {
        return try {
            val response = apiService.getPose()
            if (response.isSuccessful) {
                val pose = response.body()
                _robotPose.value = pose
                Timber.d("Current pose: $pose")
                pose
            } else {
                null
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to get pose")
            null
        }
    }

    suspend fun navigateToPoint(pointName: String): Boolean {
        return try {
            _navigationStatus.value = NavigationState.Navigating
            val request = mapOf("point" to pointName)
            val response = apiService.navigateToPoint(request)

            if (response.isSuccessful) {
                Timber.d("Navigation to $pointName started successfully")
                true
            } else {
                _navigationStatus.value = NavigationState.Error("Navigation failed: ${response.code()}")
                false
            }
        } catch (e: Exception) {
            Timber.e(e, "Navigation request failed")
            _navigationStatus.value = NavigationState.Error(e.message ?: "Unknown error")
            false
        }
    }

    suspend fun cancelNavigation(): Boolean {
        return try {
            val response = apiService.cancelNavigation()
            if (response.isSuccessful) {
                _navigationStatus.value = NavigationState.Cancelled
                Timber.d("Navigation cancelled")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to cancel navigation")
            false
        }
    }

    suspend fun updateBatteryStatus() {
        try {
            val response = apiService.getBaseEncode()
            if (response.isSuccessful) {
                response.body()?.let {
                    _batteryLevel.value = it.battery
                    Timber.d("Battery: ${it.battery}%, Charging: ${it.chargeFlag}, Emergency: ${it.emergencyButton}")
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to update battery status")
        }
    }

    suspend fun monitorNavigationStatus(): NavStatusResponse? {
        return try {
            val response = apiService.getNavStatus()
            if (response.isSuccessful) {
                // Parse the navigation status from response
                // Format: nav_result{state code name dist_to_goal mileage}
                val statusText = response.body() ?: return null
                parseNavigationStatus(statusText)
            } else {
                null
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to monitor navigation status")
            null
        }
    }

    private fun parseNavigationStatus(statusText: String): NavStatusResponse {
        // Parse format: nav_result{3 0 A 0 0.6}
        // state: 3=complete, code: 0=success
        val regex = """nav_result\{(\d+)\s+(-?\d+)\s+(\S+)\s+([\d.]+)\s+([\d.]+)\}""".toRegex()
        val match = regex.find(statusText)

        if (match != null) {
            val (state, code, goal, dist, mileage) = match.destructured
            return NavStatusResponse(
                res = state.toInt(),
                code = code.toInt(),
                goal = goal,
                dist = dist.toDouble(),
                mileage = mileage.toDouble()
            )
        }

        return NavStatusResponse(0, -1, "", -1.0, 0.0)
    }

    fun updateNavigationState(navStatus: NavStatusResponse) {
        when (navStatus.res) {
            0 -> _navigationStatus.value = NavigationState.Idle
            1 -> _navigationStatus.value = NavigationState.Navigating
            3 -> _navigationStatus.value = NavigationState.Arrived(navStatus.goal)
            4 -> _navigationStatus.value = NavigationState.Cancelled
            else -> {
                if (navStatus.code != 0) {
                    _navigationStatus.value = NavigationState.Error("Error code: ${navStatus.code}")
                }
            }
        }
    }
}
