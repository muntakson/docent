package com.library.docentbot.config

import android.content.Context
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import timber.log.Timber
import java.io.IOException

data class BoothConfigData(
    @SerializedName("basePoint")
    val basePoint: String,

    @SerializedName("booths")
    val booths: List<Booth>,

    @SerializedName("messages")
    val messages: Messages
)

data class Booth(
    @SerializedName("id")
    val id: String,

    @SerializedName("name")
    val name: String,

    @SerializedName("navigationPoint")
    val navigationPoint: String,

    @SerializedName("welcomeScript")
    val welcomeScript: String,

    @SerializedName("detailedScript")
    val detailedScript: String,

    @SerializedName("order")
    val order: Int
)

data class Messages(
    @SerializedName("welcome")
    val welcome: String,

    @SerializedName("tourStart")
    val tourStart: String,

    @SerializedName("navigatingTo")
    val navigatingTo: String,

    @SerializedName("continuePrompt")
    val continuePrompt: String,

    @SerializedName("tourCancelled")
    val tourCancelled: String,

    @SerializedName("returningToBase")
    val returningToBase: String,

    @SerializedName("tourComplete")
    val tourComplete: String,

    @SerializedName("connectionRequired")
    val connectionRequired: String
)

object BoothConfigLoader {

    private var cachedConfig: BoothConfigData? = null

    fun loadConfig(context: Context): BoothConfigData? {
        if (cachedConfig != null) {
            return cachedConfig
        }

        try {
            val jsonString = context.assets.open("booth_config.json")
                .bufferedReader()
                .use { it.readText() }

            cachedConfig = Gson().fromJson(jsonString, BoothConfigData::class.java)
            Timber.d("Booth configuration loaded successfully")
            return cachedConfig
        } catch (e: IOException) {
            Timber.e(e, "Failed to load booth configuration")
            return null
        }
    }

    fun getBooths(context: Context): List<Booth> {
        return loadConfig(context)?.booths?.sortedBy { it.order } ?: emptyList()
    }

    fun getMessages(context: Context): Messages? {
        return loadConfig(context)?.messages
    }

    fun getBasePoint(context: Context): String {
        return loadConfig(context)?.basePoint ?: "BASE"
    }
}
